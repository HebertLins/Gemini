package br.com.fiap.quotelevelling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteLevellingApplicationTests {

	@Test
	void contextLoads() {
	}

}
