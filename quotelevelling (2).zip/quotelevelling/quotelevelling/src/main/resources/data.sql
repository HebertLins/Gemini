INSERT INTO TB_ENDERECO (rua_endereco, cid_endereco, uf_endereco, cep_endereco, num_endereco)
VALUES ('Rua da Laranjinha', 'Laranjais', 'LA', '03026920', '30');

INSERT INTO TB_ENDERECO (rua_endereco, cid_endereco, uf_endereco, cep_endereco, num_endereco)
VALUES ('Rua da Bananeira Madura', 'Laranjais', 'LA', '03026123', '80');

INSERT INTO TB_ENDERECO (rua_endereco, cid_endereco, uf_endereco, cep_endereco, num_endereco)
VALUES ('Rua das Uvas Verdes', 'Laranjais', 'LA', '03026333', '23');

